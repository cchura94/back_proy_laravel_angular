<style>
    table{
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    table, th, td {
        border: 1px solid black;
    }
    th, td {
        padding: 8px 12px;
        text-align: left;
    }
</style>

<h1>Lista Pedidos</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>FECHA</th>
            <th>ESTADO</th>
            <th>CLIENTE ID</th>
            <th>USER ID</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($pedido->id); ?></td>
            <td><?php echo e($pedido->fecha); ?></td>
            <td><?php echo e($pedido->estado); ?></td>
            <td><?php echo e($pedido->cliente_id); ?></td>
            <td><?php echo e($pedido->user_id); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table><?php /**PATH D:\cursos\cla\back_proyecto_laravel_angular\resources\views/pdf/lista_pedidos.blade.php ENDPATH**/ ?>