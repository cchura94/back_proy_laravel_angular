### Descargar en Instalar GIT 
- https://www.git-scm.com/
### Crear una cuaneta en (GITHUB, GITLAB, BITBUCKET)
- En GITHUB
- Crear un repositorio
-------------------------------
### Para Conexion (Remoto - Local)
```
git init
git remote add origin https://github.com/cchura94/back_proy_laravel_angular.git
```
-----------
### Comandos:
```
git add .
git commit -m "Proyecto inicial"
git push origin master
```


